package swen90006.passbook;

import java.util.List;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.FileSystems;

import org.junit.*;
import static org.junit.Assert.*;

//By extending PartitioningTests, we inherit tests from the script
public class BoundaryTests
    extends PartitioningTests
{
    //Add another test
//    @Test public void anotherTEst()
//    {
//	//include a message for better feedback
//	final int expected = 2;
//	final int actual = 2;
//	assertEquals("Some failure message", expected, actual);
//    }
    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo1() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "12345aA";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo2() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456`A";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo3() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456{A";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo4() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456@a";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo5() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456[a";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test
    public void testAddUserNo6() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "234567nA";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test
    public void testAddUserNo7() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "234567nZ";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test
    public void testAddUserNo8() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "234567Na";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test
    public void testAddUserNo9() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "234567Nz";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test
    public void testAddUserNo10() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "abcdABC0";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test
    public void testAddUserNo11() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "0abcdABC";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo12() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "abcdABC/";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserNo13() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "abcdABC:";

        pb.addUser(passbookUsername, paraphrase);
    }
}
