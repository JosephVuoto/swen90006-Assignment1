package swen90006.passbook;

import java.util.List;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.FileSystems;
import java.util.Random;
import java.net.URL;
import java.net.MalformedURLException;

import org.junit.*;
import static org.junit.Assert.*;

public class PartitioningTests
{
    protected PassBook pb;

    //Any method annotated with "@Before" will be executed before each test,
    //allowing the tester to set up some shared resources.
    @Before public void setUp()
    {
	pb = new PassBook();
    }

    //Any method annotated with "@After" will be executed after each test,
    //allowing the tester to release any shared resources used in the setup.
    @After public void tearDown()
    {
    }

//    //Any method annotation with "@Test" is executed as a test.
//    @Test public void aTest()
//    {
//	//the assertEquals method used to check whether two values are
//	//equal, using the equals method
//	final int expected = 2;
//	final int actual = 1 + 1;
//	assertEquals(expected, actual);
//    }
//
//    @Test public void anotherTest()
//	throws DuplicateUserException, WeakPassphraseException
//    {
//	pb.addUser("passbookUsername", "properPassphrase1");
//
//	//the assertTrue method is used to check whether something holds.
//	assertTrue(pb.isUser("passbookUsername"));
//	assertFalse(pb.isUser("nonUser"));
//    }
//
//    //To test an exception, specify the expected exception after the @Test
//    @Test(expected = java.io.IOException.class)
//    public void anExceptionTest()
//	throws Throwable
//    {
//	throw new java.io.IOException();
//    }
//
//    //This test should fail.
//    //To provide additional feedback when a test fails, an error message
//    //can be included
//    @Test public void aFailedTest()
//    {
//	//include a message for better feedback
//	final int expected = 2;
//	final int actual = 1 + 2;
//	assertEquals("Some failure message", expected, actual);
//    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserEC1() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "1aA";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserEC2() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "1234567A";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserEC3() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "1234567a";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test
    public void testAddUserEC4() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);

        assertTrue(pb.isUser(passbookUsername));
    }

    @Test(expected = WeakPassphraseException.class)
    public void testAddUserEC5() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "abcdABCD";

        pb.addUser(passbookUsername, paraphrase);
    }

    @Test(expected = DuplicateUserException.class)
    public void testAddUserEC6() throws Throwable {
        String passbookUsername = "abcd";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        pb.addUser(passbookUsername, paraphrase);
    }

    @Test
    public void testAddUserEC7() throws Throwable {
        String passbookUsername = "abcd";
        String passbookUsernameNew = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        pb.addUser(passbookUsernameNew, paraphrase);

        assertTrue(pb.isUser(passbookUsernameNew));
    }

    @Test(expected = NoSuchUserException.class)
    public void testLoginUserEC1() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.loginUser(passbookUsername, paraphrase);
    }

    @Test(expected = IncorrectPassphraseException.class)
    public void testLoginUserEC2() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";
        String paraphraseNew = "123456aB";

        pb.addUser(passbookUsername, paraphrase);
        pb.loginUser(passbookUsername, paraphraseNew);
    }

    @Test
    public void testLoginUserEC3() throws Throwable {
        String passbookUsername1 = "abc";
        String paraphrase1 = "123456aA";
        String passbookUsername2 = "def";
        String paraphrase2 = "123456aAB";

        pb.addUser(passbookUsername1, paraphrase1);
        pb.addUser(passbookUsername2, paraphrase2);
        pb.loginUser(passbookUsername1, paraphrase1);
        int result = pb.loginUser(passbookUsername2, paraphrase2);

        assertTrue(result >= 0);
    }

    @Test(expected = AlreadyLoggedInException.class)
    public void testLoginUserEC4() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        pb.loginUser(passbookUsername, paraphrase);
        pb.loginUser(passbookUsername, paraphrase);
    }

    @Test(expected = NoSuchUserException.class)
    public void testLoginUserEC5() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";
        String passbookUsernameNew = "abcd";

        pb.addUser(passbookUsername, paraphrase);

        pb.loginUser(passbookUsernameNew, paraphrase);
    }

    @Test
    public void testLoginUserEC6() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int result = pb.loginUser(passbookUsername, paraphrase);

        assertTrue(result >= 0);
    }

    @Test(expected = InvalidSessionIDException.class)
    public void testUpdateDetailsEC1() throws Throwable {
        URL url = new URL("http://test.com");
        String urlUsername = "123";
        String urlPassword = "456";
        int sessionID = 123;

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);
    }

    @Test(expected = InvalidSessionIDException.class)
    public void testUpdateDetailsEC2() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        int sessionIDNew = new Random().nextInt(Integer.MAX_VALUE);
        while (sessionIDNew == sessionID) {
            sessionIDNew = new Random().nextInt(Integer.MAX_VALUE);
        }
        URL url = new URL("http://test.com");
        String urlUsername = "123";
        String urlPassword = "456";

        pb.updateDetails(sessionIDNew, url, urlUsername, urlPassword);
    }

    @Test
    public void testUpdateDetailsEC3() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "123";
        String urlPassword = "456";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        Pair<String, String> pair = pb.retrieveDetails(sessionID, url);
        assertTrue(pair != null
                && pair.getFirst().equals(urlUsername)
                && pair.getSecond().equals(urlPassword));
    }

    @Test(expected = NoSuchURLException.class)
    public void testUpdateDetailsEC4() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("https://test.com");
        String urlUsername = null;
        String urlPassword = null;

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);
        pb.retrieveDetails(sessionID, url);
    }

    @Test(expected = NoSuchURLException.class)
    public void testUpdateDetailsEC5() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("https://test.com");
        String urlUsername = null;
        String urlPassword = "123";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);
        pb.retrieveDetails(sessionID, url);
    }

    @Test(expected = NoSuchURLException.class)
    public void testUpdateDetailsEC6() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("https://test.com");
        String urlUsername = "123";
        String urlPassword = null;

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);
        pb.retrieveDetails(sessionID, url);
    }

    @Test
    public void testUpdateDetailsEC7() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("https://test.com");
        String urlUsername = "123";
        String urlPassword = "456";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        Pair<String, String> pair = pb.retrieveDetails(sessionID, url);
        assertTrue(pair != null
                && pair.getFirst().equals(urlUsername)
                && pair.getSecond().equals(urlPassword));
    }

    @Test(expected = MalformedURLException.class)
    public void testUpdateDetailsEC8() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("ftp://test.com");
        String urlUsername = "123";
        String urlPassword = "456";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);
    }

    @Test(expected = InvalidSessionIDException.class)
    public void testRetrieveDetailsEC1() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        pb.logoutUser(sessionID);
        int sessionIDNew = 123;
        pb.retrieveDetails(sessionIDNew, url);
    }

    @Test(expected = InvalidSessionIDException.class)
    public void testRetrieveDetailsEC2() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        int sessionIDNew = new Random().nextInt(Integer.MAX_VALUE);
        while (sessionIDNew == sessionID) {
            sessionIDNew = new Random().nextInt(Integer.MAX_VALUE);
        }
        pb.retrieveDetails(sessionIDNew, url);
    }

    @Test
    public void testRetrieveDetailsEC3() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        Pair<String, String> pair = pb.retrieveDetails(sessionID, url);
        assertTrue(pair != null
                && pair.getFirst().equals(urlUsername)
                && pair.getSecond().equals(urlPassword));
    }

    @Test(expected = NoSuchURLException.class)
    public void testRetrieveDetailsEC4() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.retrieveDetails(sessionID, url);
    }

    @Test
    public void testRetrieveDetailsEC5() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("https://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        Pair<String, String> pair = pb.retrieveDetails(sessionID, url);
        assertTrue(pair != null
                && pair.getFirst().equals(urlUsername)
                && pair.getSecond().equals(urlPassword));
    }

    @Test(expected = NoSuchURLException.class)
    public void testRetrieveDetailsEC6() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        URL urlNew = new URL("http://java.com");
        pb.retrieveDetails(sessionID, urlNew);
    }

    @Test(expected = MalformedURLException.class)
    public void testRetrieveDetailsEC7() throws Throwable {
        String passbookUsername = "abc";
        String paraphrase = "123456aA";

        pb.addUser(passbookUsername, paraphrase);
        int sessionID = pb.loginUser(passbookUsername, paraphrase);

        URL url = new URL("http://test.com");
        String urlUsername = "aaa";
        String urlPassword = "bbb";

        pb.updateDetails(sessionID, url, urlUsername, urlPassword);

        URL urlNew = new URL("ftp://test.com");
        pb.retrieveDetails(sessionID, urlNew);
    }
}
